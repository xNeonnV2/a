import sys
import socket
from concurrent.futures import ThreadPoolExecutor

def scan_port(ip, port):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(1)
    result = sock.connect_ex((ip, port))
    if result == 0:
        print(f"\x1b[38;5;196m[ \x1b[38;5;255mPort {port} \x1b[38;5;196m] \x1b[38;5;255m► \x1b[38;5;46mOPEN\x1b[38;5;255m")
        return port
    else:
        print(f"\x1b[38;5;196m[ \x1b[38;5;255mPort {port} \x1b[38;5;196m] \x1b[38;5;255m► \x1b[38;5;196mCLOSE\x1b[38;5;255m")

def scan_ports(ip):
    ports = [20, 21, 22, 23, 25, 53, 69, 80, 110, 123, 137, 138, 139, 143, 161, 162, 194, 389, 443, 445, 465, 500, 514, 520, 546, 547, 548, 554, 587, 631, 636, 993, 995, 1080, 1194, 1433, 1434, 1701, 1723, 3074, 3306, 3389, 5060, 5432, 5900, 5938, 8080, 8443, 9307, 19132, 25565]
    open_ports = []
    
    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = [executor.submit(scan_port, ip, port) for port in ports]
        
        for future in futures:
            result = future.result()
            if result is not None:
                open_ports.append(result)
    
    print(f"========================\n\x1b[38;5;196m[\x1b[38;5;255mTotal Open Ports\x1b[38;5;196m] \x1b[38;5;255m► \x1b[38;5;226m{len(open_ports)}\x1b[38;5;255m")
    if len(open_ports) > 0:
        print("\x1b[38;5;196m[\x1b[38;5;255mOpen Ports\x1b[38;5;196m] \x1b[38;5;255m►\x1b[38;5;226m ", end="")
        for port in open_ports:
            print(port, end=" ")
        print()

def main():
    if len(sys.argv) != 2:
        print("Usage: python scan-port.py <ip>")
        sys.exit(1)
    
    ip = sys.argv[1]
    scan_ports(ip)

if __name__ == "__main__":
    main()