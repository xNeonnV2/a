import requests
import time
from concurrent.futures import ThreadPoolExecutor

def check_proxy_live(proxy, timeout):
    try:
        start_time = time.time()
        response = requests.get('http://www.google.com', proxies={'http': proxy, 'https': proxy}, timeout=timeout)
        end_time = time.time()

        if response.status_code == 200:
            return True, end_time - start_time
    except Exception:
        pass
    
    return False, 0

def count_live_proxies(proxies):
    live_proxies = []
    dead_proxies = []

    with ThreadPoolExecutor(max_workers=50) as executor:
        future_to_proxy = {executor.submit(check_proxy_live, proxy, 2): proxy for proxy in proxies}

        for future in future_to_proxy:
            proxy = future_to_proxy[future]
            try:
                is_live, response_time = future.result()
                if is_live:
                    live_proxies.append(proxy)
                    print(f"\033[37;42mLive Proxy: {proxy} (Response Time: {response_time:.2f}s)\033[0m")
                else:
                    dead_proxies.append(proxy)
                    print(f"\033[37;41mDead Proxy: {proxy}\033[0m")
            except Exception:
                dead_proxies.append(proxy)
                print(f"\033[37;41mDead Proxy: {proxy}\033[0m")

    print(f"\nTotal Proxies: {len(proxies)}")
    print(f"Total Live Proxies: {len(live_proxies)}")
    print(f"Total Dead Proxies: {len(dead_proxies)}")

def main():
    proxies = []

    with open('proxy.txt') as file:
        proxies = file.read().splitlines()

    count_live_proxies(proxies)

if __name__ == "__main__":
    main()