import requests
import time
import threading

def get_proxies(urls):
    proxies = []

    for url in urls:
        response = requests.get(url)
        if response.status_code == 200:
            proxy_list = response.text.split('\n')
            proxies.extend(proxy_list)
    
    return proxies

def check_proxy_live(proxy, timeout, live_proxies, dead_proxies):
    try:
        start_time = time.time()
        response = requests.get('http://www.google.com', proxies={'http': proxy, 'https': proxy}, timeout=timeout)
        end_time = time.time()

        if response.status_code == 200:
            live_proxies.append(proxy)
            print(f"\033[37;42mLive Proxy: {proxy} (Response Time: {end_time - start_time:.2f}s)\033[0m")
        else:
            dead_proxies.append(proxy)
            print(f"\033[37;41mDead Proxy: {proxy}\033[0m")
    except Exception:
        dead_proxies.append(proxy)
        print(f"\033[37;41mDead Proxy: {proxy}\033[0m")

def save_proxies_to_file(proxies, filename):
    with open(filename, 'w') as file:
        file.write('\n'.join(proxies))

def main():
    urls = {
        "HTTP": [
            "https://raw.githubusercontent.com/B4RC0DE-TM/proxy-list/main/HTTP.txt",
        ],

        "HTTPS": [
            "https://proxyspace.pro/https.txt",
        ]
    }

    proxies = []

    for proxy_type, urls in urls.items():
        print(f"Getting {proxy_type} proxies...")
        proxies.extend(get_proxies(urls))
        print(f"Got {len(proxies)} {proxy_type} proxies\n")

    print(f"Total Proxies: {len(proxies)}")

    live_proxies = []
    dead_proxies = []

    threads = []

    for proxy in proxies:
        thread = threading.Thread(target=check_proxy_live, args=(proxy, 5, live_proxies, dead_proxies))
        thread.start()
        threads.append(thread)

    for thread in threads:
        thread.join()

    print(f"\nTotal Live Proxies: {len(live_proxies)}")
    print(f"Total Dead Proxies: {len(dead_proxies)}")

    save_proxies_to_file(live_proxies, 'proxy.txt')

if __name__ == "__main__":
    main()